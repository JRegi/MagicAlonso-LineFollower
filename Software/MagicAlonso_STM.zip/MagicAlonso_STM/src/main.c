//// FILE: src/main.c
#include <libopencm3/stm32/adc.h>
#include <libopencm3/stm32/usart.h>
#include "qtr_array.h"
#include "hc05.h"
#include <libopencm3/stm32/rcc.h>
#include <libopencm3/stm32/gpio.h>

static void delay_us(uint32_t us){ for (volatile uint32_t i=0; i<us*12; ++i) __asm__("nop"); }

int main(void){
    // Clocks GPIO
    rcc_periph_clock_enable(RCC_GPIOA); // sensores en PA0..PA7
    rcc_periph_clock_enable(RCC_GPIOB); // HC-05 en PB10/PB11

    // Sensores: orden físico L→R = {1,0,2,3,4,5,6,7}
    static const uint8_t  ch[8]   = {1,0,2,3,4,5,6,7}; // ADC1_INx
    static const uint32_t ports[8]= {GPIOA,GPIOA,GPIOA,GPIOA,GPIOA,GPIOA,GPIOA,GPIOA};
    static const uint16_t pins[8] = {GPIO0,GPIO1,GPIO2,GPIO3,GPIO4,GPIO5,GPIO6,GPIO7};

    qre_t q; qre_cfg_t qcfg = {
        .adc = ADC1,
        .num_sensors = 8,
        .adc_channels = ch,
        .gpio_ports = ports,
        .gpio_pins = pins,
        .has_emitters = false,
        .line_is_white = false,
        .use_ambient_sub = false,
        .smpr_default = ADC_SMPR_SMP_55DOT5CYC,
        .delay_us = delay_us,
    };
    qre_init(&q, &qcfg);

    // HC-05 por USART3 (PB10 TX, PB11 RX)
    hc05_t bt; hc05_cfg_t bcfg = {
        .usart = USART3,
        .rcc_usart = RCC_USART3,
        .tx_port = GPIOB, .tx_pin = GPIO10,
        .rx_port = GPIOB, .rx_pin = GPIO11,
        .baud = 115200,
        .use_rx = true,
    };
    hc05_init(&bt, &bcfg);
    hc05_send_str(&bt, "QRE+BT listo. 'h' para ayuda");

    // Calibración inicial
    hc05_send_str(&bt, "Calibrando 200 muestras...");
    qre_calibrate_on_samples(&q, 200, 2000);
    hc05_send_str(&bt, "OK");

    bool streaming = true;
    while (1){
        int ch_in = hc05_getc(&bt);
        if (ch_in >= 0){
            if (ch_in=='h'){
                hc05_send_str(&bt, "Comandos: c=recalib(200), s=start, x=stop, h=help");
            } else if (ch_in=='c'){
                hc05_send_str(&bt, "Recalibrando...");
                qre_calibrate_on_samples(&q, 200, 2000);
                hc05_send_str(&bt, "OK");
            } else if (ch_in=='s'){ streaming = true;  hc05_send_str(&bt, "stream ON"); }
            else if (ch_in=='x'){ streaming = false; hc05_send_str(&bt, "stream OFF"); }
        }

        if (streaming){
            uint16_t cal[8];
            qre_read_calibrated(&q, cal);
            int32_t pos = qre_read_line_position(&q, cal);
            hc05_printf(&bt, "%ld,%u,%u,%u,%u,%u,%u,%u,%u", (long)pos,
                        cal[0],cal[1],cal[2],cal[3],cal[4],cal[5],cal[6],cal[7]);
        }
        if (q.cfg.delay_us) q.cfg.delay_us(5000); // ~200 Hz
    }
}