#include "qre_array.h"
#include "esc.h"
#include "uart.h"
#include "timing.h"
#include "ui.h"
#include "clocks.h"
#include <libopencm3/stm32/rcc.h>
#include <libopencm3/cm3/systick.h>
#include <libopencm3/stm32/gpio.h>
#include <stdint.h>
#include <stdbool.h>

#define CTRL_HZ      400                  // 400 Hz → PWM “servo”
#define DT_SEC       (1.0f / CTRL_HZ)

// Centro para N=8 (0..7000)
#define SETPOINT     3500

// Ahora en μs de servo:
#define BASE_SPEED   1150                // neutral
#define MAX_SPEED    1300                 // tope alto seguro
#define MIN_SPEED    1000                 // tope bajo seguro
#define PWM_HZ       400u                 // servo @ 400 Hz

#define MOTOR_LEFT_PIN   GPIO10           // TIM1_CH3 (PA10 si corresponde a tu mapeo)
#define MOTOR_RIGHT_PIN  GPIO8            // TIM1_CH1 (PA8)

#define TIM_LEFT_MOTOR   TIM_OC3
#define TIM_RIGHT_MOTOR  TIM_OC1

#define BUTTON1_PORT GPIOB
#define BUTTON2_PORT GPIOC
#define BUTTON3_PORT GPIOC

// LEDs
#define RGB_RED_PIN    GPIO12   // PB12
#define RGB_GREEN_PIN  GPIO13   // PB13
#define RGB_BLUE_PIN   GPIO14   // PB14
#define RGB_PORT      GPIOB

// Ganancias “por muestra” (dt=2.5 ms). Punto de arranque conservador.
static float KP = 0.022f;
static float KD = 0.12f;
static int   last_error = 0;

// (dejado como lo tenías)
static const uint8_t QRE_CH[8] = {7, 6, 5, 4, 3, 2, 0, 1};
qre_array_t qre;

esc_handle_t ml, mr;

const esc_config_t escL = {
    .tim       = TIM1,
    .ch        = TIM_LEFT_MOTOR,
    .gpio_port = GPIOA,
    .gpio_pin  = MOTOR_LEFT_PIN,
    .freq_hz   = PWM_HZ,        // 400 Hz
    .min_us    = MIN_SPEED,     // 1100
    .max_us    = MAX_SPEED      // 1900
};
const esc_config_t escR = {
    .tim       = TIM1,
    .ch        = TIM_RIGHT_MOTOR,
    .gpio_port = GPIOA,
    .gpio_pin  = MOTOR_RIGHT_PIN,
    .freq_hz   = PWM_HZ,        // 400 Hz
    .min_us    = MIN_SPEED,     // 1100
    .max_us    = MAX_SPEED      // 1900 (arreglado)
};

static inline void pid_step_and_output(uint16_t position) {
    int error      = (int)position - SETPOINT;
    int derivative = error - last_error;

    int pid = (error * KP) + (derivative * KD);
    last_error = error;

    int us_right = BASE_SPEED - pid;
    int us_left  = BASE_SPEED + pid;

    if (us_right > MAX_SPEED) us_right = MAX_SPEED;
    if (us_right < MIN_SPEED) us_right = MIN_SPEED;
    if (us_left  > MAX_SPEED) us_left  = MAX_SPEED;
    if (us_left  < MIN_SPEED) us_left  = MIN_SPEED;

    esc_write_us(&mr, (uint16_t)us_right);
    esc_write_us(&ml, (uint16_t)us_left);
    //uart_printf("ML: %4u MR: %4u\n", (uint16_t)us_right, (uint16_t)us_left);
}

int main(void) {
    clocks_init();
    timing_init();
    ui_init();
    //uart_init_115200();

    delay_ms_blocking(200);

    esc_init(&ml, &escL);
    esc_init(&mr, &escR);

    delay_ms_blocking(200); 


    // Armado
    // esc_write_us(&ml, 1000);
    // esc_write_us(&mr, 1000);
    // esc_calibrate(&ml);
    // delay_ms_blocking(4000);
    // esc_calibrate(&mr);

    esc_arm(&ml);
    esc_arm(&mr);
    
    //esc_arm(&ml);
    //esc_arm(&mr);

    // Sensores
    qre_init(&qre, QRE_CH, 8);

    //uart_printf("Calibrating QRE...\n");

    // Calibración (mover la regleta por línea y fondo)
    rgb_red();
    delay_ms_blocking(500);
    qre_calibrate(&qre, 2000, 500);

    //uart_printf("Calibration done.\n");

    // Promedio (arrancá con 1 si querés tunear KP primero)
    qre_set_averaging(&qre, 1);

    //uint16_t raw_qre[8];
    rgb_off();
    rgb_blue();

    bool boton1 = false;

    uint32_t last_control_loop_update = 0;

    while (1) {
        delay_ms_blocking(100);

        if (button1_read()) {boton1 = true; 
            rgb_off(); 
            rgb_cyan();
        }

        while(boton1) {
            if (timeout_elapsed(last_control_loop_update, 2500)) {

                // 1) Lectura en fase
                uint16_t pos = qre_read_position_white(&qre);

                //uart_printf("Pos: %4u\n", pos);
            
                // 2) PID + salida
                pid_step_and_output(pos);
            }

            //uart_printf("\n");


            // for (uint8_t i = 0; i < 8; i++) {
            //     raw_qre[i] = qre_read_raw_channel(QRE_CH[i]);
            // }

            // uart_printf("QRE: %4u %4u %4u %4u %4u %4u %4u %4u\n",
            //             raw_qre[7], raw_qre[6], raw_qre[5], raw_qre[4],
            //             raw_qre[3], raw_qre[2], raw_qre[1], raw_qre[0]);


            //delay_ms_blocking(100); // simula trabajo en el loop
            
            //if (gpio_get(BUTTON1_PORT, BUTTON1_PIN)) {boton1 = false; rgb_clear(); rgb_cyan();}

        }
    }
}